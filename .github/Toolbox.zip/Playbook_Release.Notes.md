#  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
###  İletişim;
-   Discord: https://discord.gg/7hbzSGTYeZ
-   Mail: ognitorenks@gmail.com
-   Site: [https://ognitorenks.blospot.com](https://ognitorenks.blospot.com)

<details><B><summary> Versiyon 1.2 ► 27.02.2024</B></summary>

	• OgnitorenKs;
	_	• Lite kalıbı eklendi.
			• Performans kalıptan farklı bazı işlemler yapar. Başlat menüsü ve arama hizmetini siler.
		• Performans ve lite kalıplarına masaüstü arka planını özelleştirmesi için ekleme yapıldı. İşlemler sırasında Github deposundan indirilip uygulanır.
	• Kalıplara yeni ayarlar eklendi. Appx silme bölümündeki tanımlamalar yeniden düzenlendi ve hatalar giderildi.

</details><details><B><summary> Versiyon 1.1 ► 11.01.2024</B></summary>

	• Playbook ve UpdateAfter kalıplarındaki farklılıklar giderildi.

</details><details><B><summary> Versiyon 1.0 ► 10.01.2024</B></summary>

	• Deli_Petro06, OgnitorenKs, Spydea[readyOS] kalıpları güncellendi.

</details>