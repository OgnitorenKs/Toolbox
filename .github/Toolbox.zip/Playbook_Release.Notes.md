#  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
###  İletişim;
-   Discord: https://discord.gg/7hbzSGTYeZ
-   Mail: ognitorenks@gmail.com
-   Site: [https://ognitorenks.blospot.com](https://ognitorenks.blospot.com)

<details><B><summary> Versiyon 1.0 ►  10.01.2024</B></summary>

	• Deli_Petro06, OgnitorenKs, Spydea[readyOS] kalıpları güncellendi.

</details>